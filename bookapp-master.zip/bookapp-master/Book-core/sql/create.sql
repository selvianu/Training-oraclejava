CREATE TABLE books1
(id number(6) primary key, 
name varchar2(30) not null, 
publication varchar2(30) not null
);


--select * from books1;
--insert into books1 values(1,'java', 'McGraw Hills');