package test.dao;

import model.Book;
import dao.BookDAOImpl;

public class TestBookInsert {

	public static void main(String[] args) throws Exception {
		Book b = new Book();
		b.setId(102);
		b.setName("Java");
		b.setPublication("Head First");
		System.out.println(b);

		BookDAOImpl bd = new BookDAOImpl();
		bd.insert(b);
	}
  
}
